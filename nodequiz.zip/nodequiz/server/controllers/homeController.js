exports.index = function(req, res, next) {
  res.json("Home Controller works!")
};
